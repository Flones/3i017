package BD;

public class DBStatic {
	public static String mysql_host = "localhost";
	public static String mysql_db = "AHMADI_VIRAMOUTTOU";
	public static String mysql_username = "root";
	public static String mysql_password = "root";
	public static boolean mysql_pooling = false;
	
}
